CARA BELAJAR PUBLIKASI WEBSITE

1. Upload semua file ini ke hosting (folder public_html)
2. Buka domain / hosting kamu
3. Jika tampil, berarti publikasi berhasil

File:
- index.html : halaman utama
- about.html : halaman kedua
- style.css  : desain
- script.js  : interaksi sederhana
