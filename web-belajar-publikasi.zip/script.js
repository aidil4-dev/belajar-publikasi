function sayHello() {
  alert("Website berhasil dipublikasikan!");
}
